// Fill out your copyright notice in the Description page of Project Settings.


#include "IEstrategiaMovimiento.h"

// Add default functionality here for any IIEstrategiaMovimiento functions that are not pure virtual.
