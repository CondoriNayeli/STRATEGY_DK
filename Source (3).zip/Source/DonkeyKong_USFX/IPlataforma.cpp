// Fill out your copyright notice in the Description page of Project Settings.


#include "IPlataforma.h"

// Add default functionality here for any IIPlataforma functions that are not pure virtual.
